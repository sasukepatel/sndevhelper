# SN Dev Helper — a snUtils-style starter

A minimal, Manifest V3 ServiceNow developer extension you can build on. It is
intentionally small and dependency-free so the wiring is easy to read.

## Features in this starter
- **Instance info** — instance, user, node, version, and (on a form) table + sys_id.
- **Quick table open** — type `incident` → open list; `incident <sys_id>` → open
  that record; "New" → new record form.
- **Quick dev links** — Background Scripts, Script Includes, Business Rules,
  Client Scripts, UI Actions, Logs, Update Sets, Scheduled Jobs, Fix Scripts,
  Properties, REST Explorer, Flow Designer.
- **Copy current sys_id** — reads `g_form.getUniqueValue()`.
- **Technical field names** — toggle `[field_name]` badges next to form labels
  (button or `Alt+Shift+F`).
- **Translation icons** — toggle two icons next to each form label:
  - **Globe** → opens `sys_documentation` (per-language label/plural/hint) for
    that `table.field`. The field's *defining* table is resolved by walking the
    `sys_db_object.super_class` chain against `sys_dictionary`, so inherited
    fields (e.g. `task.short_description` on an incident form) resolve correctly
    instead of showing an empty list.
  - **"Languages" glyph** → opens `sys_translated_text` (per-record translated
    values), filtered to the current record (`documentkey^fieldname`) when a
    record is open, otherwise to `tablename^fieldname`.

## Install (load unpacked)
1. Unzip this folder somewhere permanent.
2. Chrome → `chrome://extensions` → enable **Developer mode** (top right).
3. **Load unpacked** → select this folder.
4. Pin the extension and open it on any `*.service-now.com` tab.

## Packaging for distribution
Run `bash package.sh` to build `sn-dev-helper.zip` containing only the files
Chrome needs. It excludes dev/meta files (`CLAUDE.md`, `.claude/`, `.git/`,
`README.md`, `node_modules/`), which don't break unpacked loading but shouldn't
ship. Never add a top-level file/folder starting with `_` — Chrome reserves
those and will refuse to load the extension.

## How it works (the important bits)
ServiceNow's classic UI runs the real app inside an iframe named `gsft_main`,
while the shell is the top frame. Two consequences shape the architecture:

1. **Two JS worlds.** A content script runs in an *isolated* world — it can
   touch the DOM but cannot see page globals like `g_form`, `g_user`, `g_ck`.
   To read those we use `chrome.scripting.executeScript({ world: "MAIN" })`
   from the popup. DOM-only work (field-name badges) stays in `content.js`.
2. **Frames.** We inject/listen across **all frames** and pick the frame that
   actually returns SN context, because the form lives in `gsft_main`.

`g_ck` is the CSRF token — grab it when you start making authenticated REST
calls (`/api/now/table/...` with the `X-UserToken` header).

## Gotchas worth knowing
- **AngularJS won't run in the popup.** MV3's extension-page CSP forbids
  `unsafe-eval`, and AngularJS compiles expressions with the Function
  constructor. Use vanilla JS / a CSP-safe framework for extension pages. (Your
  *content scripts* can still use the page's own Angular on Service Portal.)
- **Custom domains.** Many orgs front instances with a custom domain. Add it to
  `host_permissions` and `content_scripts.matches`, or switch to optional host
  permissions and request at runtime.
- **Next Experience / workspaces.** UI globals differ from classic; `g_form`
  may be absent. The probe degrades gracefully — extend it per surface.

## Natural next features (roadmap)
- Background Script runner panel (POST to `/sys.scripts.do` with `g_ck`).
- Update set switcher (read/write the `sys_update_set` user preference).
- Impersonation quick-switch.
- Table/record search backed by the Table API.
- GlideRecord snippet generator from the current form's fields.
- Favicon badge per environment (dev/test/prod) to avoid "wrong instance" edits.
